function openSignUpModal() {
      document.getElementById("signupModal").style.display = "block";
    }

    // Open the sign-in modal
    function openSignInModal() {
      document.getElementById("signinModal").style.display = "block";
    }

    // Close the modal
    function closeModal() {
      document.getElementById("signupModal").style.display = "none";
      document.getElementById("signinModal").style.display = "none";
      document.getElementById("createpostmodal").style.display = "none";
    }

    

function openCreateModal()
{
  document.getElementById("createpostmodal").style.display="block";
}